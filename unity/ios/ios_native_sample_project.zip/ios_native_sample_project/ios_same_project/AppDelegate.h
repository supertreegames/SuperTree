//
//  AppDelegate.h
//  ios_same_project
//
//  Created by hyop seung on 02/05/2017.
//  Copyright © 2017 SuperStarGame. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

